const {addToCarts, getCarts, deleteCart} = require("../controllers/cartController")
const router = require("express").Router();


router.post("/addToCarts", addToCarts )
router.get("/getCarts/:UserId" , getCarts)
router.delete("/deletecart/:UserId/:ProductId", deleteCart)
module.exports = router;