const cartModel = require("../Models/cartModels");

const { Op } = require("sequelize");
const userModel = require("../Models/userModel");
const productModel = require("../Models/productModel");

exports.addToCarts = async(req,res)=>{
    try {
        const {UserId ,ProductId , productCount } = req.body

        const user =await userModel.findByPk(UserId);
        const product =await productModel.findByPk(ProductId);

        if(!user || !product){
            return res.status(200).json({message:"user or product not found"});
        }
        const cartItem = await cartModel.create({UserId , ProductId , productCount});

        return res.status(201).json({message:"items addded to the carts" , cartItem})

    } catch (error) {
        console.log(error)
        return res.status(200).json({message:"internal server error" })

    }
}

// Find all products in the cart for a specific user
exports.getCarts =async(req, res)=> {
    const { UserId } = req.params;
  
    try {
      const user = await userModel.findByPk(UserId);
  
      if (!user) {
        return res.status(200).json({ error: 'User not found' });
      }
       const  Products = await cartModel.findAll({
        where :{UserId},
        include:[
            {model:productModel},
        ],
       })
    //   const products = user.products;
      return res.status(200).json(Products);
    } catch (error) {
      console.error('Error finding products by user id:', error);
      return res.status(500).json({ error: 'Internal server error' });
    }
  }

  exports.deleteCart = async(req,res)=>{
    try {
        const {UserId ,ProductId  } = req.params;

        const user =await userModel.findByPk(UserId);
        // const product =await productModel.findByPk(ProductId);

        if(!user ){
            return res.status(200).json({message:"user  not found"});
        }
        const cartItem = await cartModel.findOne({
            where:{UserId , ProductId},
        })
        if(!cartItem){
        return res.status(201).json({message:"product not found in the cart"})

        }
        await cartItem.destroy();

        return res.status(201).json({message:"items deleted from the carts" })

    } catch (error) {
        console.log(error)
        return res.status(200).json({message:"internal server error" })

    }
}