const orderModels = require("../Models/orderModels");

const { Op } = require("sequelize");
const userModel = require("../Models/userModel");
const productModel = require("../Models/productModel");

exports.addToCarts = async(req,res)=>{
    try {
        const {UserId ,ProductId , productCount } = req.body

        const user =await userModel.findByPk(UserId);
        const product =await productModel.findByPk(ProductId);

        if(!user || !product){
            return res.status(200).json({message:"user or product not found"});
        }
        const cartItem = await orderModels.create({UserId , ProductId , productCount});

        return res.status(201).json({message:"items addded to the carts" , cartItem})

    } catch (error) {
        console.log(error)
        return res.status(200).json({message:"internal server error" })

    }
}
