const orderModels = require("../Models/orderModels");

const { Op } = require("sequelize");
const userModel = require("../Models/userModel");
const productModel = require("../Models/productModel");
const cartModels = require("../Models/cartModels");

exports.createOrder=async(req, res)=> {
    console.log(req.body)
    try {
        const { UserId, ProductId, productCount, total } = req.body;
        const user = await userModel.findByPk(UserId);
        const product = await productModel.findByPk(ProductId);

        const order = await orderModels.create({ UserId, ProductId, productCount, 
            total});
        res.status(201).json(order);
    } catch (error) {
        res.status(500).json({ message: 'Failed to create order', error: error.message });
    }
}

// controllers/orderController.js
exports.getOrderById=async (req, res)=> {
    try {
        const orderId = req.params.orderId;
        const order = await orderModels.findByPk(orderId);
        const ORDERS = await orderModels.findAll({
            where: { orderId },
            include: [
                { model: productModel },
            ],
        })
        if (ORDERS) {
            res.status(200).json(ORDERS);
        } else {
            res.status(404).json({ message: 'Order not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Failed to get order', error: error.message });
    }
}

// controllers/orderController.js
exports.deleteOrder = async (req, res)=> {
    try {
        const orderId = req.params.orderId;
        const order = await orderModels.findByPk(orderId);
        if (order) {
            await order.destroy();
            res.status(204).json({ message: 'Order deleted successfully' });
        } else {
            res.status(404).json({ message: 'Order not found' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Failed to delete order', error: error.message });
    }
}
