const { Sequelize } = require("sequelize");


// const sequelize = new Sequelize(process.env.DB, process.env.DB_USERNAME, process.env.PASSWORD, {

//     host: process.env.HOST,

//     dialect: process.env.DIALECT

// });

const sequelize = new Sequelize("db_sdirect", "root","Rupika125$", {
    host: "127.0.0.1",
    dialect: "mysql"
});


sequelize.authenticate().then(async () => {

    console.log("Db connected")

    await sequelize.sync({force:false})



}).catch((e) => {

    console.log(e)

})




module.exports = sequelize;