const { Sequelize, DataTypes } = require("sequelize");
const sequelize = require("../database/db");
const userModel = require("./userModel");
const productModel = require("./productModel");



const orderModels = sequelize.define("giri_newOrderModel", {
    // Model attributes are defined here
    OrderId:{
    type: Sequelize.INTEGER,
        autoIncrement:true,
        primaryKey:true
    },
    UserId: {
      type: Sequelize.STRING,
      allowNull: false,
    },
    ProductId: {
      type: Sequelize.INTEGER,
      allowNull: false,
      // allowNull defaults to true
    },
    productCount: {
      type: Sequelize.INTEGER,
      allowNull: false,
    },
    total:{
      type: Sequelize.INTEGER,
        allowNull:false
    }    
  });
  
  userModel.hasMany(orderModels , {foreignKey:'UserId'})
  orderModels.belongsTo(userModel , {foreignKey:'ProductId'})
  
  productModel.hasMany(orderModels ,{foreignKey:"ProductId"})
  orderModels.belongsTo(productModel , {foreignKey:"UserId"})
  module.exports = orderModels;