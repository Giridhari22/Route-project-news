const { Sequelize, DataTypes } = require("sequelize");
const sequelize = require("../database/db");
const userModel = require("./userModel");
const productModel = require("./productModel");


const cartModels = sequelize.define("giri_newcartModel", {
  // Model attributes are defined here
  UserId: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  ProductId: {
    type: Sequelize.INTEGER,
    allowNull: false,
    // allowNull defaults to true
  },
  productCount: {
    type: Sequelize.INTEGER,
    allowNull: false,
  }
  
});

userModel.hasMany(cartModels , {foreignKey:'UserId'})
cartModels.belongsTo(userModel , {foreignKey:'UserId'})

productModel.hasMany(cartModels ,{foreignKey:"ProductId"})
cartModels.belongsTo(productModel , {foreignKey:"ProductId"})
module.exports = cartModels;