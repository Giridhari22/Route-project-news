const { createOrder, getOrderById , deleteOrder } = require("../controllers/orderController")
const router = require("express").Router();

router.post("/createOrder", createOrder)
router.get("/getOrderById/:orderId", getOrderById)
router.delete("/deleteOrder/:orderId", deleteOrder)



module.exports = router