import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./AddToCarts.css"
import axios from "axios";
import NavbarElem from "./Navbar";
import { Link, useNavigate } from "react-router-dom";





const AddToCarts = () => {

  const navigate = useNavigate()
  const [data, setData] = useState([])
  const [user, setUser] = useState(JSON.parse(localStorage.getItem("user")));
  const [total, setTotal] = useState([])
  console.log("user ka info", user)

  const getAllCartProducts = () => {
    axios
      .get(`http://localhost:4500/getCarts/${user.id}`)
      .then((response) => {
        console.log("resdata", response.data);
        setData(response.data);

      })
      .catch((err) => console.log(err));
  };

  useEffect(() => {
    getAllCartProducts();
  }, []);

  const handleDelete = async (ids) => {

    try {
      const res = await axios.delete(
        `http://localhost:4500/deletecart/${user?.id}/${ids}`,
        {
          headers: {
            Authorization: localStorage.getItem("token"),
          },
        }
      );
      getAllCartProducts();
      console.log(res);
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    handleDelete();
  }, []);




  const calculatePrice = () => {

    let totalPrice = []
    data.forEach((dt) => {
      totalPrice.push(dt.productCount * dt.giri_newProductModel.productPrice)
    })

    let totalSum = 0;
    for (let i = 0; i < totalPrice.length; i++) {
      totalSum += totalPrice[i];
    }
    setTotal(totalSum)
  }

  useEffect(() => {
    calculatePrice()
  }, [data])

  const handleOrder = async (ids , count) => {
    try {
      const users = {
        UserId: user.id,
        ProductId: ids,
        productCount: count,
        total: total
      }
      
      const res = await axios.post('http://localhost:4500/createOrder', users)
      localStorage.setItem("orderInfo", JSON.stringify(res))
     
      if (res) {
        alert("order added successfully")
       

        navigate("/home/orderItems")

      }
    } catch (error) {
      console.log(error)
    }

  }

  return (
    <div>
      <NavbarElem />
      <section class="h-100 h-custom" style={{ backgroundColor: "#d2c9ff;" }}>
        <div class="container py-5 h-100">
          <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-12">
              <div class="card card-registration card-registration-2" style={{ borderRadius: "15px;" }}>
                <div class="card-body p-0">
                  <div class="row g-0">
                    <div class="col-lg-8">
                      <div class="p-5">

                        <div class="d-flex justify-content-between align-items-center mb-5">
                          <h1 class="fw-bold mb-0 text-black">Shopping Cart</h1>
                          <h6 class="mb-0 text-muted">{data.length} items</h6>
                        </div>
                        <hr class="my-4" />
                        {data.length > 0 &&
                          data.map((dataObj) => (
                            <div>
                            <div class="row mb-4 d-flex justify-content-between align-items-center">

                              <div class="col-md-2 col-lg-2 col-xl-2">
                                <img
                                  src={dataObj.giri_newProductModel?.image}
                                  class="img-fluid rounded-3" alt="Cotton T-shirt" />
                              </div>
                              <div class="col-md-3 col-lg-3 col-xl-3">
                                <h6 class="text-muted">{dataObj.giri_newProductModel.productName}</h6>
                                <h6 class="text-black mb-0">{dataObj.giri_newProductModel.category}</h6>
                              </div>

                              <div class="col-md-3 col-lg-3 col-xl-3 d-flex">
                                <button class="btn btn-link px-2"
                                  onclick="this.parentNode.querySelector('input[type=number]').stepDown()">
                                  <i class="fas fa-minus">-</i>
                                </button>

                                <input id="form1" min="0" name="quantity" value={dataObj.productCount} type="number"
                                  class="form-control form-control-sm" />

                                <button class="btn btn-link px-2"
                                  onclick="this.parentNode.querySelector('input[type=number]').stepUp()">
                                  <i class="fas fa-plus">+</i>
                                </button>
                              </div>

                              <div class="col-md-3 col-lg-2 col-xl-2 offset-lg-1">
                                <h6 class="mb-0">{dataObj.giri_newProductModel.productPrice * dataObj.productCount}</h6>
                              </div>
                              <div class="col-md-1 col-lg-1 col-xl-1 text-end">
                                <button className="btn btn-danger" onClick={() => { handleDelete(dataObj?.ProductId) }} >remove</button>
                              </div>
                            </div>
                            <div>
                              <button type="button" class="btn btn-dark btn-block btn-lg"
                                data-mdb-ripple-color="dark"
                                  onClick={() => { handleOrder(dataObj?.ProductId, dataObj.productCount ) }}

                              >
                                order
                              </button>
                              </div>
                            </div>

                          ))}



                        <hr class="my-4" />

                        <div class="pt-5">
                          <h6 class="mb-0"><a href="/home" class="text-body"><i
                            class="fas fa-long-arrow-alt-left me-2"></i>Back to shop</a></h6>
                        </div>


                      </div>
                    </div>
                    <div class="col-lg-4 bg-grey">
                      <div class="p-5">
                        <h3 class="fw-bold mb-5 mt-2 pt-1">Summary</h3>
                        <hr class="my-4" />

                        <div class="d-flex justify-content-between mb-4">
                          <h5 class="text-uppercase">items {data.length}</h5>

                        </div>





                        <hr class="my-4" />

                        <div class="d-flex justify-content-between mb-5">
                          <h5 class="text-uppercase">Total price</h5>
                          <h5> {total}</h5>
                        </div>

                       

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default AddToCarts