import "bootstrap/dist/css/bootstrap.min.css";

import axios from "axios";

import React, { useState, useEffect } from "react";
import NavbarElem from "./Navbar";
import { useNavigate } from "react-router-dom";




const AllProducts = () => {
    const [data, setData] = useState([])
    const [user, setUser] = useState(JSON.parse(localStorage.getItem("user")));
   
    const [cart, setCart] = useState()
    const [count, setCount] = useState(1)
    const navigate =  useNavigate()
    const getAllProducts = () => {
        return axios
            .get(`http://localhost:4500/getAllProduct/`)
            .then((response) => {
                console.log(response.data);
                setData(response.data.data);

            })
            .catch((err) => console.log(err));
    };

    useEffect(() => {
        getAllProducts();
    }, []);

    const postCarts =async(count,id)=>{
        try {
            
            const users = {
                UserId : user.id,
                ProductId:id,
                productCount:count
               }
            const res = await axios.post ('http://localhost:4500/addToCarts', users) 
            if(res){
                alert("product added successfully")
                navigate("/home/addToCarts")

            }
            console.log(res)
        } catch (error) {
            console.log(error)
        }

    //   console.log("count" , count)
    //   console.log("data ka id" , id)
    //   console.log("userId" , user.id)
    }

    return (
        <div>
            <NavbarElem />

            <section style={{ backgroundColor: "#eee;" }}>
                <div class="text-center  container py-5">
                    <h4 class="mt-4 mb-5">
                        <strong>Welcome To The GiriCart</strong>
                    </h4>

                    <div class="row showProducts">
                        {data.length > 0 &&
                            data.map((dataObj) => (
                                <div
                                    class="card col-lg-3 col-sm-6 m-2"
                                    style={{ position: "relative" }}
                                >
                                    <div
                                        class="bg-image hover-zoom ripple ripple-surface ripple-surface-light"
                                        data-mdb-ripple-color="light"
                                    >
                                        <img src={dataObj.image} class="w-100" alt="jk" />
                                        {/* <button
                        class="btn btn-danger"
                        onClick={() => handleDelete(dataObj.id)}
                        style={{
                          fontSize: "0.8rem",
                          fontWeight: 800,
                          cursor: "pointer",
                          position: "absolute",
                          right: "0.5rem",
                          bottom: 0,
                        }}
                      >
                        Delete product
                      </button> */}
                                        <td>
                                            <label className="txt">quantity</label>
                                            <select
                                                style={{
                                                    fontSize: "0.8rem",
                                                    fontWeight: 800,
                                                    cursor: "pointer",
                                                    position: "absolute",
                                                    right: "0.1rem",
                                                    width: "60px",
                                                    bottom: 0,
                                                }}
                                                defaultValue="Choose..."
                                                className="form-control dropdown"
                                                name="menu"
                                               
                                                onChange={(e) => setCount(e.target.value)}
                                            >
                                                <option value="Choose...">1</option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                                <option value="7">7</option>
                                                <option value="8">8</option>
                                                <option value="9">9</option>
                                                <option value="10">10</option>

                                            </select>

                                        </td>
                                        <div class="mask"></div>
                                        <div class="hover-overlay">
                                            <div
                                                class="mask"
                                                style={{
                                                    backgroundColor: "rgba(251, 251, 251, 0.15);",
                                                }}
                                            ></div>
                                            <button
                                                type="button"
                                                class="btn btn-primary"
                                                //   onClick={() => handleEdit(dataObj.id)}
                                                style={{
                                                    fontSize: "0.8rem",
                                                    fontWeight: 800,
                                                    cursor: "pointer",
                                                    position: "absolute",
                                                    left: "0.5rem",
                                                    bottom: 0,
                                                }}
                                                onClick={()=>{postCarts(count , dataObj.id )}}
                                            >
                                                Add To Cart
                                            </button>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title mb-3">{dataObj.productName}</h5>
                                        <p>{dataObj.category}</p>

                                        <h6 class="mb-3">{dataObj.productPrice}</h6>
                                    </div>
                                </div>
                            ))}
                    </div>
                </div>
            </section>

        </div>
    )
}

export default AllProducts